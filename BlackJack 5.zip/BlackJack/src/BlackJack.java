import java.util.Scanner;

public class BlackJack {
	private Dealer dealer;
	private AbstractPlayer player;
	private int dealerWins;
	private int playerWins;

	public BlackJack() {
		dealer = new Dealer();
		player = new AbstractPlayer();
		dealerWins = 0;
		playerWins = 0;
	}

	public void playGame() {
		Scanner keyboard = new Scanner(System.in);
		String choice;

		do {
			dealer.shuffle();

			player.addCardToHand(dealer.deal());
			dealer.addCardToHand(dealer.deal());
			player.addCardToHand(dealer.deal());
			dealer.addCardToHand(dealer.deal());

			System.out.println("Current hand " + player.toString());

			while (player.getHandValue() < 21) {
				System.out.println("Do you want to hit? [Y/N]");
				choice = keyboard.next().toUpperCase();

				if (choice.equals("Y")) {
					player.addCardToHand(dealer.deal());
					System.out.println("Current hand " + player.toString());
				} else {
					break;
				}
			}

			while (dealer.hit()) {
				dealer.addCardToHand(dealer.deal());
			}

			System.out.println("PLAYER\n" + "Hand Value :: " + player.getHandValue() + "\nHand Size :: " + player.getHandSize() + "\nCards in Hand :: " + player.toString());
			System.out.println("DEALER\n" + "Hand Value :: " + dealer.getHandValue() + "\nHand Size :: " + dealer.getHandSize() + "\nCards in Hand :: " + dealer.toString());

			if (player.getHandValue() > 21 && dealer.getHandValue() <= 21) {
				System.out.println("\nDealer wins - Player busted!");
				dealerWins++;
			} else if (player.getHandValue() <= 21 && dealer.getHandValue() > 21) {
				System.out.println("\nPlayer wins - Dealer busted!");
				playerWins++;
			} else if (player.getHandValue() > 21 && dealer.getHandValue() > 21) {
				System.out.println("Both players bust!");
			} else if (player.getHandValue() < dealer.getHandValue()) {
				System.out.println("\nDealer has bigger hand value!");
				dealerWins++;
			} else {
				System.out.println("\nPlayer has bigger hand value!");
				playerWins++;
			}

			System.out.println("\nDealer has won " + dealerWins + " times.");
			System.out.println("Player has won " + playerWins + " times.");

			System.out.println("\nDo you want to play again? [Y,y,N,n] ::");
			choice = keyboard.next().toUpperCase();

			player.resetHand();
			dealer.resetHand();

		} while (choice.equals("Y"));
	}

	public static void main(String[] args) {
		BlackJack game = new BlackJack();
		game.playGame();
	}
}